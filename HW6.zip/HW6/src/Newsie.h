/*
 * Newsie.h
 *
 *  Created on: Feb 29, 2020
 *      Author: Lena
 */

#ifndef NEWSIE_H_
#define NEWSIE_H_
#include <string>
#include <vector>

using namespace std;

typedef enum{
	News,
	Opinions_n_Editorials,
	Features,
	Sports,
	Entertainment,
	Humor,
	NONE
}article;

typedef enum{
	Editor,
	Deputy_Editor,
	Assistant_Editor,
	Reporter,
	Cub_Reporter
}position;

typedef struct{
	article desk;//New desk, sports desk, etc.
	string temptitle; //working title of piece to be written
	bool assigned; //default to false; true only once assigned to writer
	struct Newsie* assigned_Newsie;

	}assignment;



class Newsie {

public:
	string firstname_;
	string lastname_;
	float gpa_;
	int IDnum_;

	position title_;

	article primary_;
	article secondary_;
	article tertiary_;

	int term_goal_;
	int term_kount_;
	int terms_;

	string non_de_plume_;

	assignment current_priority_;
	assignment current_extra_;
	assignment current_emergency_;

	string convertDesk(int desk);
	string convertPosition(int position);
	void print_weekly_rollcall(vector<Newsie> allwriters);
	void print_weekly_assignment_desk(vector<assignment> allassignments);
	};

#endif /* NEWSIE_H_ */
