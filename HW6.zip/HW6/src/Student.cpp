/*
 * Student.cpp
 *
 *  Created on: Feb 21, 2020
 *      Author: Lena Dias
 */

#include "Student.h"

Student::Student() {
	// TODO Auto-generated constructor stub

}

Student::~Student() {
	// TODO Auto-generated destructor stub
}

string Student::getFirst()
{
	return first_;
}
void Student::setFirst(string first)
{
	first_= first;
}

string Student::getLast()
{
    	return last_;
}
void Student::setLast(string last)
{
	last_=last;
}

float Student::getGPA()
{
    return gpa_;
}
void Student::setGPA(float gpa)
{
	gpa_=gpa;
}

int Student::getID()
{
	return id_;
}
void Student::setID(int ID)
{
	id_=ID;
}


// print_info() should print in the format (GPA has 2 decimal places):
// Chris Jones, GPA: 3.50, ID: 2014
void Student::print_info()
{
	cout << getFirst()<< " " << getLast() << ", GPA: " << getGPA() << ", ID: " << getID() << endl;
}
