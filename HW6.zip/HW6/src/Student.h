/*
 * Student.h
 *
 *  Created on: Feb 21, 2020
 *      Author: Lena Dias
 */

#ifndef STUDENT_H_
#define STUDENT_H_

#include <iostream>
#include <string>
#include "Newsie.h"

using namespace std;

class Student {

// Google style guide suggests trailing underscores for private members.
private:
    string first_;
    string last_;
    float gpa_;
    int id_;

public:
    Student();

	Student(
	        string &first_name, string &last_name, float gpa, int id):
	            first_(first_name), last_(last_name), gpa_(gpa), id_(id) { }

	virtual ~Student();

    string getFirst();
    void setFirst(string first);

    string getLast();
	void setLast(string last);

    float getGPA();
    void setGPA(float gpa);

    int getID();
	void setID(int ID);

	void print_info();



};

#endif /* STUDENT_H_ */
