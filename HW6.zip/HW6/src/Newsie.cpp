//============================================================================
// Name        : Newsie.cpp
// Author      : Lena Dias
// Description : CS2303 C02 HW 6
//============================================================================

/*
 ============================================================================
 Name        : Newsies Tester.c
 Author      : Lena Dias
 Description : CS2303 C02 HW 6
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include "Newsie.h"
#include "LenaDias.h"

using namespace std;

//used to get string from enum
string convertDesk(int desk)
{
	switch(desk)
	{
	case 0 :
		return "News";
	case 1 :
		return "Opinions n Editorials";
	case 2 :
			return "Features";
	case 3 :
			return "Sports";
	case 4 :
			return "Entertainment";
	case 5 :
			return "Humor";
	case 6 :
			return "NONE";

	}
}
//used to get string from enum
string convertPosition(int position)
{
	switch(position)
	{
	case 0 :
		return "Editor";
	case 1 :
		return "Deputy Editor";
	case 2 :
			return "Assistant Editor";
	case 3 :
			return "Reporter";
	case 4 :
			return "Cub Reporter";
	}
}

void print_weekly_rollcall(vector<Newsie> allwriters)
{
	printf("\nWeekly rollcall: \n");
	for(int i=0; i<allwriters.size(); i++)
	{
		cout << allwriters[i].firstname_ << " "<< allwriters[i].non_de_plume_ << " "<< allwriters[i].lastname_ << " "<< convertPosition(allwriters[i].title_) << "\n";
		if(allwriters[i].current_priority_.desk==6 && allwriters[i].current_extra_.desk==6 &&allwriters[i].current_emergency_.desk==6)
		{
			cout << "\t NONE \n";
		}
		else
		{
			cout << "\t"<< convertDesk(allwriters[i].current_priority_.desk) << " "<< allwriters[i].current_priority_.temptitle << "\n";
			cout << "\t"<< convertDesk(allwriters[i].current_extra_.desk) << " "<< allwriters[i].current_extra_.temptitle << "\n";
			cout << "\t"<< convertDesk(allwriters[i].current_emergency_.desk) << " " << allwriters[i].current_emergency_.temptitle << "\n";
		}

	}
}
void print_weekly_assignment_desk(vector<assignment> allassignments)
{
	printf("\nWeekly assignment desk: \n");
	for(int i=0; i<allassignments.size(); i++)
	{
		if(allassignments[i].assigned==false)
		{
			cout << "UNASSIGNED " << convertDesk(allassignments[i].desk) << " "<< allassignments[i].temptitle<< "\n";
		}
		else
		{
			cout << allassignments[i].assigned_Newsie->lastname_ <<" "<< convertPosition(allassignments[i].assigned_Newsie->title_)<< " " << convertDesk(allassignments[i].desk) << " "<< allassignments[i].temptitle<< "\n";
		}
	}
}

int main(void) {
	puts("Some terminal and file I/O!");

	// Pointer to the file
	     ifstream NewsiesFP("NewsiesStaff.txt");

	     vector<Newsie> newsieList;

	     string firstname_;
	     string lastname_;
	     float gpa_;
	     int IDnum_;

	     int title_; //position

	     int primary_; //articles
	     int secondary_;
	     int tertiary_;

	     int term_goal_;
	     int term_kount_;
	     int terms_;

	     string non_de_plume_;


	     int sentinel = 0;

	     //used to determine if a writer has an assignment assigned to this "current" slot
	     assignment nullassignment;
	     nullassignment.desk=NONE;
	     nullassignment.temptitle="NONE";

	     NewsiesFP >> sentinel;
	     printf("\nNewsie Staff Info\n");
	     for (int kount = 1; kount <= sentinel;kount++)
	     {


			 NewsiesFP >> firstname_;
			 NewsiesFP >> lastname_;
			 NewsiesFP >> gpa_;
			 NewsiesFP >> IDnum_;
			 NewsiesFP >> title_;
			 NewsiesFP >> primary_;
			 NewsiesFP >> secondary_;
			 NewsiesFP >> tertiary_;
			 NewsiesFP >> term_goal_;
			 NewsiesFP >> term_kount_;
			 NewsiesFP >> terms_;
			 NewsiesFP >> non_de_plume_;

	    	 cout << firstname_ << " " <<lastname_ << "\n";

			 Newsie entry;
			 string firstnamestr(firstname_);
			 entry.firstname_=firstnamestr;
			 string lastnamestr(lastname_);
			 entry.lastname_=lastnamestr;
			 entry.gpa_=gpa_;
			 entry.IDnum_=IDnum_;
			 entry.title_=static_cast<position>(title_);
			 entry.primary_=static_cast<article>(primary_);
			 entry.secondary_=static_cast<article>(secondary_);
			 entry.tertiary_=static_cast<article>(tertiary_);
			 entry.term_goal_=term_goal_;
			 entry.term_kount_=term_kount_;
			 entry.terms_=terms_;
			 string nondeplumestr(non_de_plume_);
			 entry.non_de_plume_=nondeplumestr;
			 entry.current_priority_=nullassignment;
			 entry.current_extra_=nullassignment;
			 entry.current_emergency_=nullassignment;



			 newsieList.push_back(entry);
	     }



	     // Pointer to the file
	     	     ifstream AssignmentDeskFP("AssignmentEditorTxt.txt");

	     	     int desk; //article
	     	     string temptitle;

	     	     vector<assignment> assignments;



	     	     AssignmentDeskFP >> sentinel;
	     	     printf("\nAssignment Desk\n");
	     	     for (int kount = 1; kount <= sentinel;kount++)
	     	     {

					 AssignmentDeskFP >> desk;
					 AssignmentDeskFP >> temptitle;
					 cout << desk << " ";
					 cout << temptitle << "\n";

					 assignment story;
					 story.desk=static_cast<article>(desk);
					 story.temptitle=temptitle;
					 assignments.push_back(story);

	     	     }



	     	     printf("\n\nA Newsie takes up %d bytes.\nWhy so much?\n\n", sizeof(Newsie));



	     	     printf("\nBegin assignment assigning\n");
	     	     fflush(stdout);

	     	     assignment currentAssignment = assignments[0];
	     	     for(int i=0; i<assignments.size(); i++)
	     	     {
	     	    	 bool articleAssigned = false; //tracks whether article has been assigned
	     	    	 int k = 0; //tracks place in newsieList

	     	    	 while(articleAssigned==false)
	     	    	 {
						 if((assignments[i].desk==newsieList[k].primary_)
								 ||(assignments[i].desk==newsieList[k].secondary_)
								 ||(assignments[i].desk==newsieList[k].tertiary_)
										 )
						 {
							 if (newsieList[k].current_priority_.desk==NONE)
							 {
								 newsieList[k].current_priority_=assignments[i];
								 assignments[i].assigned_Newsie=&newsieList[k];
								 assignments[i].assigned=true;
								 articleAssigned=true;
							 }
							 else if (newsieList[k].current_extra_.desk==NONE)
							 {
								 newsieList[k].current_extra_=assignments[i];
								 assignments[i].assigned_Newsie=&newsieList[k];
								 assignments[i].assigned=true;
								 articleAssigned=true;
							 }
							 else if (newsieList[k].current_emergency_.desk==NONE)
							 {
								 newsieList[k].current_emergency_=assignments[i];
								 assignments[i].assigned_Newsie=&newsieList[k];
								 assignments[i].assigned=true;
								 articleAssigned=true;
							 }
							 else
							 {
								 k++;
								 articleAssigned=false;
							 }
						 }
						 else
						 {
							 k++;
							 articleAssigned=false;
						 }
	     	    	 }
	     	     }


	     	     printf("Assignment assigning complete.");
	     	     fflush(stdout);

	     	     print_weekly_rollcall(newsieList);
	     	     print_weekly_assignment_desk(assignments);






	return 0;
}


